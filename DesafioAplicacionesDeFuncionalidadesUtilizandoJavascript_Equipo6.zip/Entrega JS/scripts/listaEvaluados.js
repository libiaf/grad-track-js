const apiUrl = "https://67dbbdb81fd9e43fe475acff.mockapi.io/api/djs/listaEvaluados"

function loadUsers(){
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            console.log(data[0]);
            const tableBody = document.querySelector('#data-table tbody');
            data.forEach (item => {
                const row = document.createElement("tr");
                row.innerHTML = `
                    <td> ${item.id} </td> 
                    <td> ${item.nombre} </td> 
                    <td> ${item.apellidos} </td>
                    <td><button class="btn btn-transparent"><img src="/images/ver_mas.png" alt="Icono Ver Más"></button></td>
                    <td><button class="btn btn-transparent"><img src="/images/eliminar.png" alt="Icono Eliminar"></button></td>
                    `;
                tableBody.appendChild(row);
            })
        })
        .catch(error => console.error('Error al cargar los datos: ', error));
}

window.onload = function() {
    loadUsers();
};