const apiUrl = "https://67dbbdb81fd9e43fe475acff.mockapi.io/api/djs/listaEvaluados";

function botonActivo(idBoton, selectorGrupo) {
  const button = document.getElementById(idBoton);

  button.addEventListener('click', (e) => {
    e.preventDefault(); 
    const allButtons = document.querySelectorAll(selectorGrupo);
    allButtons.forEach(b => b.classList.remove('active'));

    button.classList.add('active');
  });
}

botonActivo('btnGeneroMujer', '.btn-genero');  
botonActivo('btnGeneroHombre', '.btn-genero'); 
botonActivo('btnGraduadoSi', '.btn-graduado');  
botonActivo('btnGraduadoNo', '.btn-graduado');  


function addElement() {
  const name1 = document.getElementById("name").value;
  const apellidos1 = document.getElementById("apellidos").value;
  const curp1 = document.getElementById("curp").value;

  const genero1 = document.querySelector('#btnGeneroMujer.active') ? 'Mujer' :
                  document.querySelector('#btnGeneroHombre.active') ? 'Hombre' : '';
  const graduado1 = document.querySelector('#btnGraduadoSi.active') ? 'SI' :
                    document.querySelector('#btnGraduadoNo.active') ? 'NO' : '';


  const newUser = {
    nombre: name1,
    apellidos: apellidos1,
    curp: curp1,
    genero: genero1,
    graduado: graduado1, 
  };

  fetch(apiUrl, {
    method: "POST",
    body: JSON.stringify(newUser),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  })
    .then((response) => response.json())
    .then((data) => {
      alert("El elemento se añadió exitosamente");
      window.location.href = "../pages/listaEvaluados.html"; 
    })
    .catch((error) => {
      alert("El proceso de añadir un elemento falló");
    });
}

const form = document.querySelector('form'); 
form.addEventListener("submit", (e) => {
  e.preventDefault();  
  addElement();  
});

document.querySelector('.cancelar').addEventListener('click', (e) => {
  e.preventDefault();  
  window.location.href = '../pages/listaEvaluados.html'; 
});

document.getElementById('AgregarEvaluado').addEventListener('click', () => {
  window.location.href = '../pages/agregarEvaluado.html';
});





